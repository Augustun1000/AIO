#!/bin/bash
#Copyright (C) 2023 Augustun1000 <augustoperezriesgo@gmail.com>
tint2 &
comptom &
nitrogen --restore &
