#!/bin/bash

function Power() {
    xterm -e poweroff
}
function Reboot() {
    xterm -e reboot
}
function Reboot-Openbox() {
    cmd=openbox --reboot
}
function Exit-Openbox() {
    cmd= openbox --exit
}
##
# Color  Variables
##
green='\e[32m'
blue='\e[34m'
clear='\e[0m'
##
# Color Functions
##
ColorGreen(){
	echo -ne $green$1$clear
}
ColorBlue(){
	echo -ne $blue$1$clear
}
menu(){
echo -ne "
Power menu
$(ColorGreen '1)') Power Off
$(ColorGreen '2)') Reboot
$(ColorGreen '3)') Reboot-Openbox
$(ColorGreen '4)') Exit-Openbox
$(ColorGreen '0)') Cancel o Ctrl+z
$(ColorBlue 'Choose an option:') "
        read a
        case $a in
	        1) Power Off ; menu ;;
	        2) Reboot ; menu ;;
	        3) Reboot-Openbox ; menu ;;
	        4) Exit-Openbox ; menu ;;
		0) exit 0 ;;
		*) echo -e $red"Wrong option."$clear; WrongCommand;;
        esac
}
# Call the menu function
menu
