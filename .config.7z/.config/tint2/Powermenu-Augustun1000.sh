#! /bin/bash
#Copyright (C) 2024 Augustun1000 <augustoperezriesgo@gmail.com>

action=$(yad --center --width 300 --entry --title "System Logout" \
    --image=gnome-shutdown \
    --button="close:1" --button="ok:0" \
    --text "Choose action:" \
    --entry-text \
    "Power Off" "Reboot" "Exit-openbox")
    
case $action in
    Power*) cmd="poweroff" ;;
    Reboot*) cmd="reboot" ;;
    Exit-openbox*) cmd="openbox --exit" ;;
    esac

eval exec $cmd
