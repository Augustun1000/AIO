#! /bin/bash
#Copyright (C) 2024 Augustun1000 <augustoperezriesgo@gmail.com>

action=$(yad --center --width 300 --entry --title "System Logout" \
    --button="close:1" --button="ok:0" \
    --text "Choose action:" \
    --entry-text \
    "Power Off" "Reboot" "Reboot-Openbox" "Exit-Openbox")
    
case $action in
    Power*) cmd="poweroff" ;;
    Reboot*) cmd="reboot" ;;
    Reboot-Openbox*) cmd="openbox --reboot" ;;
    Exit-Openbox*) cmd="openbox --exit" ;;
    esac

eval exec $cmd
