#! /bin/bash
#Copyright (C) 2024 Augustun1000 <augustoperezriesgo@gmail.com>

action=$(yad --center --width 300 --entry --title "Utilities" \
    --button="close:1" --button="ok:0" \
    --text "Choose action:" \
    --entry-text \
    "Upgrade-System" "Upgrade-Aur" "Music-Player" "Terminal-Browser" "File-Viewer-Cli" "Disk-Usage-Cli" "Compare-Files")
    
case $action in
    Upgrade-System*) cmd="kitty -e sudo pacman -Syyu" ;;
    Upgrade-Aur*) cmd="kitty -e yay -Syyu" ;;
    Music-Player*) cmd="kitty -e cmus" ;;
    Terminal-Browser*) cmd="kitty -e w3m google.com" ;;
    File-Viewer-Cli*) cmd="kitty -e ranger" ;;
    Disk-Usage-Cli*) cmd="kitty -e ncdu" ;;
    Compare-Files*) cmd="meld" ;;
    esac

eval exec $cmd
