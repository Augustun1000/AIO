#!/bin/bash
#Copyright (C) 2024 Augustun1000 <augustoperezriesgo@gmail.com>

function Upgrade-System() {
    sudo pacman -Syyu
}
function Upgrade-Aur() {
    yay -Syyu
}
function Music-Player-Cli() {
    cmus
}
function Terminal-Browser() {
    w3m google.com
}
function File-Viewer-Cli() {
    ranger
}
function Disk-Usage-Cli() {
    ncdu
}
function Compare-Files() {
    meld
}
##
# Color  Variables
##
green='\e[32m'
blue='\e[34m'
clear='\e[0m'
##
# Color Functions
##
ColorGreen(){
	echo -ne $green$1$clear
}
ColorBlue(){
	echo -ne $blue$1$clear
}
menu(){
echo -ne "
Utilities menu
$(ColorGreen '1)') Upgrade-System
$(ColorGreen '2)') Upgrade-Aur
$(ColorGreen '3)') Music-Player-Cli
$(ColorGreen '4)') Terminal-Browser
$(ColorGreen '5)') File-Viewer-Cli
$(ColorGreen '6)') Disk-Usage-Cli
$(ColorGreen '7)') Compare-Files
$(ColorGreen '0)') Cancel o Ctrl+z
$(ColorBlue 'Choose an option:') "
        read a
        case $a in
	        1) Upgrade-System ; menu ;;
	        2) Upgrade-Aur ; menu ;;
	        3) Music-Player-Cli ; menu ;;
	        4) Terminal-Browser ; menu ;;
	        5) File-Viewer-Cli ; menu ;;
	        6) Disk-Usage-Cli ; menu ;;
	        7) Compare-Files ; menu ;;
		0) exit 0 ;;
		*) echo -e $red"Wrong option."$clear; WrongCommand;;
        esac
}
# Call the menu function
menu
